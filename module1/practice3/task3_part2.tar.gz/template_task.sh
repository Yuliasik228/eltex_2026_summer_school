#!/bin/bash

SCRIPT_NAME=$(basename "$0")

if [ "$SCRIPT_NAME" == "template_task.sh" ]; then
	echo "я бригадир, сам не работаю"
	exit 1
fi

CHANNEL="/tmp/run/cuckoo.pid"
REPORT="report_${SCRIPT_NAME}.log"
REPLY_PIPE="/tmp/run/reply_$$.pid"

echo "$(date "+%Y-%m-%d %H:%M:%S") [$$] Скрипт запущен" >> "$REPORT"

rm -f "$REPLY_PIPE"
mkfifo "$REPLY_PIPE"
chmod 600 "$REPLY_PIPE"

echo "${SCRIPT_NAME}[$$]: how much time do I have? ${REPLY_PIPE}" > "$CHANNEL"

read -r N < "$REPLY_PIPE"

rm -f "$REPLY_PIPE"

sleep "$N"

echo "$(date "+%Y-%m-%d %H:%M:%S") [$$] Скрипт завершился, работал ${N} секунд" >> "$REPORT"
