#!/bin/bash

CONF="observer.conf"
LOG="observer.log"

is_process_running() {
	local script="$1"
	for pid_dir in /proc/[0-9]*/cmdline; do
		if [ -r "$pid_dir" ]; then
			cmdline=$(tr '\0' ' ' < "$pid_dir" 2>/dev/null)
			if echo "$cmdline" | grep -q "$script"; then
				return 0
			fi
		fi
	done
	return 1
}

while IFS= read -r script_name || [ -n "$script_name" ]; do
	if [ -z "$script_name" ] || [[ "$script_name" == \#* ]]; then
		continue
	fi
	if ! is_process_running "$script_name" && [ -x "$script_name" ]; then
		nohup ./"$script_name" > /dev/null 2>&1 &
		echo "$(date "+%Y-%m-%d %H:%M:%S") Перезапуск: $script_name (PID: $!)" >> "$LOG"
	fi
done < "$CONF"
