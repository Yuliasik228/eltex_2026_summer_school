#!/bin/bash

DIR="/tmp/run"
F_NAME="cuckoo.pid"
CHANNEL="${DIR}/${F_NAME}"
LOG="cuckoo.log"

mkdir -p "$DIR"

rm -f "$CHANNEL"
mkfifo "$CHANNEL"
chmod 666 "$CHANNEL"

trap 'echo "$(date "+%Y-%m-%d %H:%M:%S") Shutdown!" >> "$LOG"; rm -f "$CHANNEL"; exit 0' SIGTERM

echo "$(date "+%Y-%m-%d %H:%M:%S") Startup!" >> "$LOG"

while true; do
	if read -r message < "$CHANNEL"; then
		if [[ "$message" =~ ^([a-zA-Z0-9._-]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?\ /tmp/run/reply_([0-9]+)\.pid$ ]]; then
			NAME="${BASH_REMATCH[1]}"
			PID="${BASH_REMATCH[2]}"
			REPLY_PIPE="${BASH_REMATCH[3]}"
			N=$((2 + RANDOM % 9))
			echo "$N" > "/tmp/run/reply_${REPLY_PIPE}.pid"
			echo "$(date "+%Y-%m-%d %H:%M:%S") ${NAME}[${PID}] ${N}" >> "$LOG"
		fi
	fi
done
